/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.addbook;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.awt.Window;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import library.assistant.database.DBHandler;

/**
 * FXML Controller class
 *
 * @author Shahwar
 */
public class AddBookController implements Initializable {

    @FXML
    private JFXButton savebtn;
    @FXML
    private JFXButton cancelbtn;
    @FXML
    private JFXTextField titletxt;
    @FXML
    private JFXTextField idtxt;
    @FXML
    private JFXTextField authortxt;
    @FXML
    private JFXTextField publishertxt;
    
    DBHandler dbh;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        dbh =  DBHandler.getInstance();
        checkData();
    }    

    @FXML
    public void onSave(ActionEvent event) {
        String bookId = idtxt.getText();
        String bookName = titletxt.getText();
        String bookAuthor = authortxt.getText();
        String bookPub = publishertxt.getText();
        
        if(bookId.isEmpty()|| bookName.isEmpty()|| bookAuthor.isEmpty()|| bookPub.isEmpty()){
            Alert alt = new Alert(Alert.AlertType.ERROR);
            alt.setHeaderText(null);
            alt.setContentText("Please Fill All Required Fields");
            alt.showAndWait();
            return;
            /*
             stm.execute("CREATE TABLE" + TABLE_NAME + "("
                + "   id varchar(200) primary key, \n"
                + "   title varchar(200),\n"
                + "   author varchar(200),\n"
                + "   publisher varchar(200),\n"
                + "   intcode varchar(100),\n"
                + "   isAvail boolean default true"
                + " )");
            */
        }
        String sql = "INSERT INTO BOOK VALUES (" 
                + "'" + bookId + " ', " 
                + "'" + bookName + " ', "  
                + "'" + bookAuthor + " ', "  
                + "'" + bookPub + " ', " 
                + "" + "true" + ""
                +")";
        System.out.println(sql);
        if(dbh.executeAction(sql)){
            Alert alt = new Alert(Alert.AlertType.INFORMATION);
            alt.setHeaderText(null);
            alt.setContentText("Sucessfully Saved");
            alt.showAndWait();
            
        }else /*for eeror*/{
            Alert alt = new Alert(Alert.AlertType.ERROR);
            alt.setHeaderText(null);
            alt.setContentText("Failed");
            alt.showAndWait();
            
        }
    }

    @FXML
    public void onCancel(MouseEvent event) {
      ((Node)event.getSource()).getScene().getWindow().hide();
    }
   

    private void checkData()  {
        String querry = "SELECT * FROM BOOK";
        ResultSet rs = dbh.execQuerry(querry);
       
        try {
            while(rs.next()){
                String titletxt = rs.getString("titletxt");
                String idtxt = rs.getString("idtxt");
                String authortxt = rs.getString("authortxt");
                String publishertxt = rs.getString("publishertxt");
                /*System.out.println(titletxt);
                System.out.println(idtxt);
                System.out.println(authortxt);
                System.out.println(publishertxt);
                */
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddBookController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        }
}
