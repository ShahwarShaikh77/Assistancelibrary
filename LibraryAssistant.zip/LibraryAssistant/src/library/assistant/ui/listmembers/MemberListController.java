/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.listmembers;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import library.assistant.database.DBHandler;
import library.assistant.ui.listmembers.MemberListController;


/**
 * FXML Controller class
 *
 * @author Shahwar
 */
public class MemberListController implements Initializable {
     ObservableList<MemberListController.Member> list = FXCollections.observableArrayList();

    @FXML
    private TableView<Member> tableview;
    @FXML
    private TableColumn<Member, String> namecol;
    @FXML
    private TableColumn<Member, String> midcol;
    @FXML
    private TableColumn<Member, String> mobilecol;
    @FXML
    private TableColumn<Member, String> emailcol;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       initCol();
       loadData();
    }   
    private void initCol() {
               namecol.setCellValueFactory(new PropertyValueFactory<>("nametxt"));
               midcol.setCellValueFactory(new PropertyValueFactory<>("midtxt"));
               mobilecol.setCellValueFactory(new PropertyValueFactory<>("mobiletxt"));
               emailcol.setCellValueFactory(new PropertyValueFactory<>("emailtxt"));
               }
    private void loadData() {
        DBHandler dbh =  DBHandler.getInstance();
        String querry = "SELECT * FROM MEMBER";
        ResultSet rs = dbh.execQuerry(querry);
       
        try {
            while(rs.next()){
                String nametxt = rs.getString("nametxt");
                String midtxt = rs.getString("midtxt");
                String mobiletxt = rs.getString("mobiletxt");
                String emailtxt = rs.getString("emailtxt");
               
                list.add(new Member(nametxt, midtxt, mobiletxt, emailtxt));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MemberListController.class.getName()).log(Level.SEVERE, null, ex);
        }
            tableview.getItems().setAll(list);
        
          }
    
    public static class Member{
        
        private final SimpleStringProperty nametxt;
        private final SimpleStringProperty midtxt;
        private final SimpleStringProperty mobiletxt;
        private final SimpleStringProperty emailtxt;
        
        
        Member(String nametxt, String midtxt, String mobiletxt , String emailtxt){
            this.nametxt = new SimpleStringProperty(nametxt);
            this.midtxt = new SimpleStringProperty(midtxt);
            this.mobiletxt = new SimpleStringProperty(mobiletxt);
            this.emailtxt = new SimpleStringProperty(emailtxt);
            
            
        }

        public String getNametxt() {
            return nametxt.get();
        }

        public String getMidtxt() {
            return midtxt.get();
        }

        public String getMobiletxt() {
            return mobiletxt.get();
        }

        public String getEmailtxt() {
            return emailtxt.get();
        }

       
     
        
    }
}
