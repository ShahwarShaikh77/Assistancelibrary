/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.main;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.effects.JFXDepthManager;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import library.assistant.database.DBHandler;
import library.assistant.ui.listmembers.MemberListController;

/**
 * FXML Controller class
 *
 * @author Shahwar
 */
public class MainController implements Initializable {

    @FXML
    private HBox bookInfoHbox;
    @FXML
    private HBox memberInfoHbox;
    @FXML
    private JFXTextField bookidInput;
    @FXML
    private Text bookname;
    @FXML
    private Text authorname;
    @FXML
    private Text statustxt;
    @FXML
    private JFXButton cancelbtn;
   
    
   
    

    DBHandler dbh;
    @FXML
    private JFXButton cancelbtn1;
    @FXML
    private JFXTextField memberidInput;
    @FXML
    private Text memberName;
    @FXML
    private Text memberMobile;
    @FXML
    private Text memberEmail;
    
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        JFXDepthManager.setDepth(bookInfoHbox, 4);
       JFXDepthManager.setDepth(memberInfoHbox, 4);
       dbh = DBHandler.getInstance();
        
    }    

    @FXML
    private void loadAddMember(ActionEvent event) {
        loadWindow("/library/assistant/ui/addmember/AddMember.fxml","Add New Member");
    }

    @FXML
    private void loadAddBook(ActionEvent event) {
        loadWindow("/library/assistant/ui/addbook/AddBook.fxml", "Add New Book");
    }

    @FXML
    private void loadViewMembers(ActionEvent event) {
        loadWindow("/library/assistant/ui/listmembers/MemberList.fxml", "View Members List");
    }

    @FXML
    private void loadViewBooks(ActionEvent event) {
        loadWindow("/library/assistant/ui/listbooks/BookList.fxml", "View Books List");
    }
    void loadWindow(String loc, String title){
        try {
            Parent pt = FXMLLoader.load(getClass().getResource(loc));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene (pt));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @FXML
    public void onBookInfo(ActionEvent event) {
        clearBookCache();
          String id = bookidInput.getText();
          String querry = "SELECT * FROM BOOK WHERE idtxt = '" + id + "'";
          ResultSet rs = dbh.execQuerry(querry);
          Boolean flag = false;
          try{
              while(rs.next()){
                  String titletxt = rs.getString("titletxt");
                  String authortxt = rs.getString("authortxt");
                  Boolean bStatus = rs.getBoolean("isAvail");
                  bookname.setText(titletxt);
                  authorname.setText(authortxt);
                  String status = (bStatus)?" Available " : " Not Available ";
                  statustxt.setText(status);
                  
                  flag= true;
              }
              if(!flag){
                  bookname.setText("No Such Book Available");
              }
             }catch (SQLException ex) {
                          Logger.getLogger(MemberListController.class.getName()).log(Level.SEVERE, null, ex);
             }
}
    @FXML
    private void onmemberInfo(ActionEvent event) {
        clearMemberCache();
        String midtxt = memberidInput.getText();
        String querry = "SELECT * FROM MEMBER WHERE midtxt = '"+midtxt+"'";
        ResultSet rs = dbh.execQuerry(querry);
        Boolean flag = false;
        try {
            while(rs.next()){
                String nametxt = rs.getString("nametxt");
                String mobiletxt = rs.getString("mobiletxt");
                String emailtxt = rs.getString("emailtxt");
                memberName.setText(nametxt);
                memberMobile.setText(mobiletxt);
                memberEmail.setText(emailtxt);
                
                flag = true;
            }
            if(!flag){
                memberName.setText("No Such Member is Available");
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    void clearBookCache(){
        bookname.setText("");
        authorname.setText("");
        statustxt.setText("");
    }
    void clearMemberCache(){
        memberName.setText("");
        memberMobile.setText("");
        memberEmail.setText("");
    }

    @FXML
    private void onCancel(ActionEvent event) {
        System.exit(0);
    }

   
    

    @FXML
    private void onIssue(ActionEvent event) {
        
        String bookId = bookidInput.getText();
        
       Alert al = new Alert(Alert.AlertType.CONFIRMATION);
       al.setTitle("Confirm Issue Operation");
       al.setHeaderText(null);
       al.setContentText("Are you Sure?" + bookname.getText());
       
       Optional<ButtonType>response = al.showAndWait();
       if(response.get()==ButtonType.OK){
           String str = "INSERT INTO ISSUE (bookId) VALUES (  "
                  
                  + "'" + bookId + "')";
           
           String str2 = "UPDATE BOOK SET isAvail  = false WHERE idtxt = '" + bookId + "'";
           System.out.println(str + " and " + str2);
           if(dbh.executeAction(str)){
                Alert al1 = new Alert(Alert.AlertType.INFORMATION);
                al1.setTitle("Successfully Issued");
                al1.setHeaderText(null);
                al1.setContentText("Book Issue Operation Complete" );
                al1.showAndWait();
           }else{
                Alert al2 = new Alert(Alert.AlertType.ERROR);
                al2.setTitle("Failed Issueing Operation");
                al2.setHeaderText(null);
                al2.setContentText("Book Issue Operation not Complete " );
                al2.showAndWait();
           }
       }
    }

    
}