/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.main;

/**
 *
 * @author Shahwar
 */
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import library.assistant.database.DBHandler;

/**
 *
 * @author Shahwar
 */
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
         Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
        Scene sc = new Scene(root);
        Stage stage = new Stage();
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setScene(sc);
        stage.show();
        new Thread(() ->{
        DBHandler.getInstance();    
        }).start(); 
        
        }
    public static void main(String[] args) {
        launch(args);
    }
    
}