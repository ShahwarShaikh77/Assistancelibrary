/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.listbooks;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import library.assistant.database.DBHandler;
import library.assistant.ui.addbook.AddBookController;

/**
 * FXML Controller class
 *
 * @author Shahwar
 */
public class BookListController implements Initializable {
   
   ObservableList<Book> list = FXCollections.observableArrayList();

    @FXML
    private TableView<Book> tableview;
    @FXML
    private TableColumn<Book, String> titlecol;
    @FXML
    private TableColumn<Book, String> idcol;
    @FXML
    private TableColumn<Book, String> authorcol;
    @FXML
    private TableColumn<Book, String> pubcol;
    @FXML
    private TableColumn<Book, Boolean> availcol;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       initCol();
       
       loadData();
    }   

    private void initCol() {
               titlecol.setCellValueFactory(new PropertyValueFactory<>("titletxt"));
               idcol.setCellValueFactory(new PropertyValueFactory<>("idtxt"));
               authorcol.setCellValueFactory(new PropertyValueFactory<>("authortxt"));
               pubcol.setCellValueFactory(new PropertyValueFactory<>("publishertxt"));
               availcol.setCellValueFactory(new PropertyValueFactory<>("availability"));
          }

    private void loadData() {
        DBHandler dbh =  DBHandler.getInstance();
        String querry = "SELECT * FROM BOOK";
        ResultSet rs = dbh.execQuerry(querry);
       
        try {
            while(rs.next()){
                String titletxt = rs.getString("titletxt");
                String idtxt = rs.getString("idtxt");
                String authortxt = rs.getString("authortxt");
                String publishertxt = rs.getString("publishertxt");
                Boolean avail = rs.getBoolean("isAvail");
                
                list.add(new Book(titletxt, idtxt, authortxt, publishertxt, avail));
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddBookController.class.getName()).log(Level.SEVERE, null, ex);
        }
            tableview.getItems().setAll(list);
        
          }
    
    public static class Book{
        
        private final SimpleStringProperty titletxt;
        private final SimpleStringProperty idtxt;
        private final SimpleStringProperty authortxt;
        private final SimpleStringProperty publishertxt;
        private final SimpleBooleanProperty availability;
        
        Book(String titletxt, String idtxt, String authortxt , String publishertxt, Boolean avail){
            this.titletxt = new SimpleStringProperty(titletxt);
            this.idtxt = new SimpleStringProperty(idtxt);
            this.authortxt = new SimpleStringProperty(authortxt);
            this.publishertxt = new SimpleStringProperty(publishertxt);
            this.availability = new SimpleBooleanProperty(avail);
            
        }

        public String getTitletxt() {
            return titletxt.get();
        }

        public String getIdtxt() {
            return idtxt.get();
        }

        public String getAuthortxt() {
            return authortxt.get();
        }

        public String getPublishertxt() {
            return publishertxt.get();
        }

        public Boolean getAvailability() {
            return availability.get();
        }
        
        
    }
    
}
