package library.assistant.database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import javax.swing.JOptionPane;

/**
 *
 * @author Shahwar
 */
public class DBHandler {
    private static DBHandler dbh = null;
    private static final String URL= "jdbc:derby:database;create= true";
    private static Connection conn = null;
    private static Statement stm = null;
    
    private DBHandler(){
        createConnection(); 
        setupBookTable();
        setupMemberTable();
        setupIssueTable();
    }
    public static DBHandler getInstance(){
        if(dbh == null){
            dbh = new DBHandler();
            
        }
        return dbh;
    }
    
    void createConnection(){
        
        try{
             Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
             conn = DriverManager.getConnection(URL);
            
        }catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex) {
            
        }
    }
    
    void setupBookTable(){
        String TABLE_NAME = "BOOK";
        try{
            
            stm = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println(" Table " + TABLE_NAME +  " Already Exist, Ready for Go! ");
            }else{
                stm.execute(" CREATE TABLE " + TABLE_NAME + "("
                + "   idtxt varchar(200) primary key, \n"
                + "   titletxt varchar(200), \n"
                + "   authortxt varchar(200), \n"
                + "   publishertxt varchar(100), \n"
                + "   isAvail boolean default true"
                + " )");
            }
           }catch (SQLException ex) {
            System.err.println(ex.getMessage() + " .... setupDatabase");
           }finally{
      }
    }
    public ResultSet execQuerry(String querry){
        ResultSet rs;
        try{
            stm = conn.createStatement();
            rs = stm.executeQuery(querry);
            
        }catch (Exception ex) {
            System.out.println("Exception at executeQuerry:DBHandler" + ex.getLocalizedMessage());
            return null;
            
        }finally{
            
        }
        return rs;
    }
    public boolean executeAction(String querry2){
        try{
            stm = conn.createStatement();
            stm.execute(querry2);
            return true;
            
        }catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Error :" +  ex.getMessage(), "Error Occured" , JOptionPane.ERROR_MESSAGE);
            System.out.println("Exception at ExecuteQuerry: DBHandler" + ex.getLocalizedMessage());
            return false;
            
        }finally{
            
        }
       
    }

    void setupMemberTable() {
        String TABLE_NAME = "MEMBER";
        try{
            
            stm = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println(" Table " + TABLE_NAME +  " Already Exist, Ready for Go!" );
            }else{
                stm.execute(" CREATE TABLE " + TABLE_NAME + "("
                + "   midtxt varchar(200) primary key,\n"
                + "   nametxt varchar(200), \n"
                + "   mobiletxt varchar(20), \n"
                + "   emailtxt varchar(100)"
                + " )" );
            }
            
            
        }catch (SQLException ex) {
            System.err.println(ex.getMessage() + " .... setupDatabase");
            
        }finally{
            
        }
         }
    
        void setupIssueTable(){
            String TABLE_NAME = "ISSUE";
            try{
                stm = conn.createStatement();
                DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println(" Table " + TABLE_NAME +  " Already Exist, Ready for Go! ");
            }else{
                stm.execute(" CREATE TABLE " + TABLE_NAME + "("
                + "   bookID varchar(200) primary key, \n"
                + "   memberID varchar(200), \n"
                + "   issueTime timestamp default CURRENT_TIMESTAMP, \n"
                + "   renew_count integer default 0,\n "
                + "   FOREIGN KEY (bookID) REFERENCES BOOK(idtxt) ,\n "
                + "   FOREIGN KEY (memberID) REFERENCES MEMBER(midtxt) "
                + " )" );
            }
                
            }catch (Exception ex) {
                System.err.println(ex.getMessage() + " .... setupDatabse ");
                
            }finally{
                
            }

}    
}

