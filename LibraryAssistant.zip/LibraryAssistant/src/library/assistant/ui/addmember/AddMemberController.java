/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.assistant.ui.addmember;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import library.assistant.database.DBHandler;

/**
 * FXML Controller class
 *
 * @author Shahwar
 */
public class AddMemberController implements Initializable {
    DBHandler dbh;

    @FXML
    private JFXTextField nametxt;
    @FXML
    private JFXTextField midtxt;
    @FXML
    private JFXTextField mobiletxt;
    @FXML
    private JFXTextField emailtxt;
    @FXML
    private JFXButton cancelbtn;
    @FXML
    private JFXButton addmemberbtn;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        dbh =  DBHandler.getInstance();
    }    


    
    public void onCancel(MouseEvent event) {
        ((Node)event.getSource()).getScene().getWindow().hide();
    }

    @FXML
    public void onAddMember(ActionEvent event) {
        String mName = nametxt.getText();
        String mId = midtxt.getText();
        String mMobile = mobiletxt.getText();
        String mEmail = emailtxt.getText();
        
        Boolean flag = mName.isEmpty() || mId.isEmpty()|| mMobile.isEmpty()|| mEmail.isEmpty();
        if(flag){ 
        
        Alert alt = new Alert(Alert.AlertType.ERROR);
            alt.setHeaderText(null);
            alt.setContentText("Please Fill All Required Fields");
            alt.showAndWait();
            return;
        }
        /*  stm.execute(" CREATE TABLE " + TABLE_NAME + "("
                + "   midtxt varchar(200) primary key, \n"
                + "   nametxt varchar(200), \n"
                + "   mobiletxt varchar(20), \n"
                + "   emailtxt varchar(100), \n"
                + " )"); */
        String st = "INSERT INTO MEMBER VALUES ("  
               + " ' " + mId + " ', " 
               + " ' " + mName + " ', " 
               + " ' " + mMobile + " ', " 
               + " ' " + mEmail + " ' " 
               + " ) ";
        System.out.println(st);
        if(dbh.executeAction(st)){
            Alert alt = new Alert(Alert.AlertType.INFORMATION);
            alt.setHeaderText(null);
            alt.setContentText("Member Added Successfully! ");
            alt.showAndWait();
            
            
        }else{
            Alert alt = new Alert(Alert.AlertType.ERROR);
            alt.setHeaderText(null);
            alt.setContentText("Something is Wrong");
            alt.showAndWait();
            
        }
                
                
                
                
    }
    
}
